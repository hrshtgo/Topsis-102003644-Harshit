# Topsis-Harshit-102003644
Python Package for Calculation of Multiple Criteria Decision Making using Topsis
# Requirements:
Topsis-Harshit-102003644 requires pip, numpy and pandas to be pre-installed.
# Installation:
You can install the package with the following command: 
```
pip install Topsis-Harshit-102003644==2.0
```
# Working:
```
102003644 <InputDataFile> <Weights> <Impacts> <ResultFileName>
```